
import tkinter as tk
from tkinter import messagebox, ttk
import yfinance as yf
import pandas as pd
import ta
import datetime

class GoldAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Gold Analyzer Pro")
        self.root.geometry("500x400")
        self.root.resizable(False, False)

        self.style = ttk.Style()
        self.style.configure("TButton", font=("Arial", 12))
        self.style.configure("TLabel", font=("Arial", 11))
        
        self.label = ttk.Label(root, text="تحليل الذهب - Gold Analyzer Pro", font=("Arial", 14, "bold"))
        self.label.pack(pady=20)

        self.analyze_btn = ttk.Button(root, text="ابدأ التحليل", command=self.analyze_gold)
        self.analyze_btn.pack(pady=10)

        self.output_text = tk.Text(root, height=12, width=60, font=("Courier", 9))
        self.output_text.pack(pady=10)

    def analyze_gold(self):
        self.output_text.delete("1.0", tk.END)
        try:
            end = datetime.datetime.now()
            start = end - datetime.timedelta(days=180)
            data = yf.download('GC=F', start=start, end=end, interval='1d')
            data['rsi'] = ta.momentum.RSIIndicator(close=data['Close']).rsi()
            data['macd'] = ta.trend.MACD(close=data['Close']).macd_diff()
            data['ema20'] = ta.trend.EMAIndicator(close=data['Close'], window=20).ema_indicator()
            data['ema50'] = ta.trend.EMAIndicator(close=data['Close'], window=50).ema_indicator()
            last = data.iloc[-1]

            output = f"تاريخ: {data.index[-1].date()}\n"
            output += f"سعر الإغلاق: {last['Close']:.2f}\n"
            output += f"RSI: {last['rsi']:.2f}\n"
            output += f"MACD: {last['macd']:.4f}\n"
            output += f"EMA 20: {last['ema20']:.2f} | EMA 50: {last['ema50']:.2f}\n\n"

            if last['rsi'] < 30 and last['ema20'] > last['ema50']:
                output += "إشارة شراء قوية (RSI منخفض و EMA صاعد)"
            elif last['rsi'] > 70 and last['ema20'] < last['ema50']:
                output += "إشارة بيع قوية (RSI مرتفع و EMA هابط)"
            else:
                output += "لا توجد إشارة قوية حاليًا"

            self.output_text.insert(tk.END, output)
        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء التحليل: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = GoldAnalyzerApp(root)
    root.mainloop()
